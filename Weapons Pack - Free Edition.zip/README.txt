Weapons Pack - Free Edition
===========================

Thank you for downloading this resource!

If you need any help or you found any bugs
feel free to reach us on Discord: https://discord.gg/fBQRQyAsj7

Nexo Instructions:
- Drag the Nexo folder into your main plugins directory & the files will automatically merge with your current Nexo folder.

ItemsAdder Instructions:
- Drag the ItemsAdder folder into your main plugins directory & the files will automatically merge with your current ItemsAdder folder.

What's included:
- 6 custom 2D weapon textures: Cosmic Sword, Storm Katana, Poison Dagger, Frost Axe,
  Molten Mace and Reaper's Scythe.
- Item IDs are the weapon names, for example cosmic_sword. In ItemsAdder the full ID is
  weapons_pack_free:cosmic_sword.

Base materials:
- Swords, Katanas, Daggers and Scythes use DIAMOND_SWORD, Axes use DIAMOND_AXE, and Maces use MACE.
  This only affects the vanilla attack/durability stats of the base item. You can change the
  "material" line of any item in the config (Nexo) or the "resource: material" line
  (ItemsAdder) to use a different base item, or set your own stats and attributes on top.

Files folder:
- The "Files" folder contains the original 16x16 textures for your own edits.
  It is not needed to run the pack.

Want more? The full Weapons Pack has 54 weapons in 7 categories.
